#!/usr/bin/env python3


from brain_games.games.logic import game_logic
from brain_games.games.calc import tutorial, game


def main():
    game_logic(tutorial, game)
